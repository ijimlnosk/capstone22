package com.daelim.capstone22.fragment

import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.daelim.capstone22.*
import com.daelim.capstone22.`object`.ApiObject
import com.daelim.capstone22.data.ListRequest
import com.daelim.capstone22.data.ListResponse
import kotlinx.android.synthetic.main.fragment_list.*
import kotlinx.android.synthetic.main.list_item.*
import retrofit2.*

class ListFragment : Fragment() {

    private val BASE_URL = "http://192.168.17.1"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val v = inflater.inflate(R.layout.fragment_list, container, false)
        return v
    }

    private fun setAdapter(requestList: ArrayList<ListResponse>){
        val myAdapter = RecyclerAdapter(requestList,requireContext())
        recycler_view.adapter = myAdapter
        recycler_view.layoutManager = LinearLayoutManager(context)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadData()

        /*val context = context as MainActivity
        val centerlist = resources.getStringArray(R.array.simple_Region1)

        val lv = context.findViewById<ListView>(R.id.list)
        val adapter = ArrayAdapter(context, android.R.layout.simple_list_item_1, centerlist)
        lv.adapter = adapter
*/
    }
    private fun loadData()
    {
        ApiObject.listService.requestBodyList().enqueue(object : Callback<ListRequest>{
            override fun onResponse(call: Call<ListRequest>, response: Response<ListRequest>) {
             if (response.isSuccessful){
                 val listBody = response.body()
                 listBody?.let {
                     setAdapter(it.result)
                     Log.d("BodyList",it.result.toString())
                 }
             }
            }
            override fun onFailure(call: Call<ListRequest>, t: Throwable) {
                Log.d("list body error",t.message.toString())
            }
        })
    }
}