package com.daelim.capstone22

import android.app.Application
import dagger.hilt.android.HiltAndroidApp


class MainApplication: Application() {
    companion object{
        lateinit var prefs: TokenSharedPreference
    }

    override fun onCreate() {
        super.onCreate()
        prefs = TokenSharedPreference(applicationContext)
    }


}