package com.daelim.capstone22.data

import com.google.gson.annotations.SerializedName
import java.util.*

data class SignUpResponse(
    @SerializedName("message") val message:String
)
