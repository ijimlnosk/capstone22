package com.daelim.capstone22.VO

data class CalendarVO(
    var cl_date: String = "", // 날짜
    var cl_day: String= "" // 요일
)
