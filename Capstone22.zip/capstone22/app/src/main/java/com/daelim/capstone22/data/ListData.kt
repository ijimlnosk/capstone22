package com.daelim.capstone22.data

class ListData(val breakdown: String, val pay:String, val name: String)