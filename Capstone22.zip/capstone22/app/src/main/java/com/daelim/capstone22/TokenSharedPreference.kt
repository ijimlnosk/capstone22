package com.daelim.capstone22

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil.setContentView
import java.nio.channels.spi.AbstractSelectionKey

class TokenSharedPreference(context: Context){
    private val prefs: SharedPreferences = context.getSharedPreferences("jwt",Context.MODE_PRIVATE)

    fun getString(key: String, defValue: String): String{
        return prefs.getString(key, defValue).toString()
    }
    fun setString(key: String, str:String){
        prefs.edit().putString(key,str).apply()
    }
}