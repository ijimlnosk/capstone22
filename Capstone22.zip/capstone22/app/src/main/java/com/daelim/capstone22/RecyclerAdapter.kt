package com.daelim.capstone22

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.daelim.capstone22.data.ListRequest
import com.daelim.capstone22.data.ListResponse

class RecyclerAdapter(val listResponse: ArrayList<ListResponse>, val context: Context)
    : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>(){
    /*class ListAdapter(val context: Context, val listData: ArrayList<ListRequest>) : BaseAdapter() {
    override fun getCount(): Int {
        return listData.size
    }

    override fun getItem(position: Int): Any {
        return listData[position]
    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getView(position: Int, converView: View, parent: ViewGroup?): View {

        val view: View = LayoutInflater.from(context).inflate(androidx.appcompat.R.id.list_item,null)

        val tvBreakD = view.findViewById<TextView>(R.id.tvBD)
        val tvMoney  = view.findViewById<TextView>(R.id.tvPay)
        val tvcateG = view.findViewById<TextView>(R.id.tvCate)

        val initData = listData[position]

        return view
    }*/
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.list_item,parent,false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listResponse[position],context)
    }

    override fun getItemCount(): Int {
        return listResponse.count()
    }

    class ViewHolder(itemView: View?): RecyclerView.ViewHolder(itemView!!) {

        val amount = itemView?.findViewById<TextView>(R.id.tvAmount)
        val name = itemView?.findViewById<TextView>(R.id.tvName)
        val transaction = itemView?.findViewById<TextView>(R.id.tvTransaction)
        val category = itemView?.findViewById<TextView>(R.id.tvCategory)

        fun bind(itemList: ListResponse?, context: Context){
            amount?.text = itemList?.amount.toString()
            name?.text = itemList?.name
            transaction?.text = itemList?.transactionType
            category?.text = itemList?.categoryType
        }
    }
}
