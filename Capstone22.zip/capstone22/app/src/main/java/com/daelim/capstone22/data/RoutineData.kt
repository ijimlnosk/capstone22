package com.daelim.capstone22.data

import com.daelim.capstone22.color.RoutineColor

class RoutineData (
    private var title: String? = null,
    private var titleColor: RoutineColor? = null,
    private var round: Int? = null,
    private var second: Int? = null
) {

    fun getTitle(): String? {
        return title
    }

    fun setTitle(title: String?) {
        this.title = title
    }

    fun getTitleColor(): RoutineColor? {
        return titleColor
    }

    fun setTitleColor(title: RoutineColor?) {
        this.titleColor = titleColor
    }

    fun getRound(): Int? {
        return round
    }

    fun setRound(round: Int?) {
        this.round = round
    }

    fun getSecond(): Int? {
        return second
    }

    fun setSecond(second: Int?) {
        this.second = second
    }

}