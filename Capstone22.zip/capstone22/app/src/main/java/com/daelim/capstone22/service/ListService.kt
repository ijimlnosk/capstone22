package com.daelim.capstone22.service

import android.content.SharedPreferences
import com.daelim.capstone22.TokenSharedPreference
import com.daelim.capstone22.data.*
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST

interface ListService {

    @Headers("Content-Type: application/json")
    @POST("transaction")
    fun requestHeaderList(@Header("authorization") accessToken:String):Call<SignUpResponse>
    fun requestBodyList(@Body listResponse: ListResponse) : Call<ListRequest>
    abstract fun requestBodyList(): Call<ListRequest>
}