package com.daelim.capstone22.data

import com.google.gson.annotations.SerializedName

data class ListRequest(
    val result : ArrayList<ListResponse>
)
