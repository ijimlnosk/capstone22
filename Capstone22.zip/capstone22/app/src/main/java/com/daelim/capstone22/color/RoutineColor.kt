package com.daelim.capstone22.color

enum class RoutineColor {
    RED,
    ORANGE,
    YELLOW,
    GREEN,
    BLUE,
    NAVY,
    PURPLE,
    DARK_GRAY,
    LIGHT_GRAY,
    WHITE
}
